export const lightTheme = {
    background: "#FA5252",
    card: "#AD0000",
    text: "#121212",
    label: "#555",
    border: "#ccc",
    result: "#007bff",
    infoBg: "#fff",
    infoBorder: "#eee",
  };
  