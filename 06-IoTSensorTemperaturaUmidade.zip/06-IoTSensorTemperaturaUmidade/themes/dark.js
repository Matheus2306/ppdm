export const darkTheme = {
    background: "#32025C",
    card: "#091447",
    text:"#f5f5f5",
    label: "#aaa",
    border: "#444",
    buttonPrimary: "#3399ff",
    buttonDanger: "#ff4d4d",
    result: "#66ccff",
    infoBg: "#1e1e1e",
    infoBorder: "#333",
}